package ec.edu.uce.dominio;
/**
 * Clase de prueba para la funcionalidad de la clase {@link Fecha}.
 * Se validan los métodos de acceso y modificación de los atributos de fecha.
 */
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class FechaTest {
    /**
     * Se verifica la asignación correcta del día y la validación de valores inválidos.
     */
    @Test
    void setDia() {
        Fecha fecha = new Fecha(10, 5, 2025);
        fecha.setDia(15);
        assertEquals(15, fecha.getDia());
        // día inválido (ejemplo: 32)
        fecha.setDia(32);
        assertEquals(15, fecha.getDia(), "No debe cambiar el día si es inválido");
    }
    /**
     * Se verifica la asignación correcta del mes y la validación de valores inválidos.
     */
    @Test
    void setMes() {
        Fecha fecha = new Fecha(10, 5, 2025);
        fecha.setMes(8);
        assertEquals(8, fecha.getMes());
        // mes inválido (ejemplo: 13)
        fecha.setMes(13);
        assertEquals(8, fecha.getMes(), "No debe cambiar el mes si es inválido");
    }
    /**
     * Se verifica la asignación correcta del año y la validación de valores inválidos.
     */
    @Test
    void setAnio() {
        Fecha fecha = new Fecha(10, 5, 2025);
        fecha.setAnio(2030);
        assertEquals(2030, fecha.getAnio());
        // año inválido (ejemplo: 1800)
        fecha.setAnio(1800);
        assertEquals(2030, fecha.getAnio(), "No debe cambiar el año si es inválido");
    }
    /**
     * Se verifica la correcta recuperación del día.
     */

    @Test
    void getDia() {
        Fecha fecha = new Fecha(5, 6, 2024);
        assertEquals(5, fecha.getDia());
    }
    /**
     * Se verifica la correcta recuperación del mes.
     */
    @Test
    void getMes() {
        Fecha fecha = new Fecha(5, 6, 2024);
        assertEquals(6, fecha.getMes());
    }
    /**
     * Se verifica la correcta recuperación del año.
     */
    @Test
    void getAnio() {
        Fecha fecha = new Fecha(5, 6, 2024);
        assertEquals(2024, fecha.getAnio());
    }
    /**
     * Se verifica que la fecha se formatee correctamente en formato corto (dd/mm/yyyy).
     */
    @Test
    void obtenerFormatoCorto() {
        Fecha fecha = new Fecha(5, 6, 2024);
        assertEquals("05/06/2024", fecha.obtenerFormatoCorto());
    }
    /**
     * Se verifica que la fecha se formatee correctamente en formato largo (Ejemplo: 5 de junio de 2024).
     */
    @Test
    void obtenerFormatoLargo() {
        Fecha fecha = new Fecha(5, 6, 2024);
        assertEquals("5 de junio de 2024", fecha.obtenerFormatoLargo());
    }
    /**.
     * Se verifica la representación en cadena de la fecha.
     */
    @Test
    void testToString() {
        Fecha fecha = new Fecha(5, 6, 2024);
        assertEquals("05/06/2024", fecha.toString());
    }
}
