package ec.edu.uce.dominio;
/**
 * Clase de prueba para la funcionalidad de la clase {@link Cliente}.
 * Se validan los constructores, getters y setters.
 */
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class ClienteTest {
    Cliente cliente;

    @BeforeEach
    void setUp() {
        cliente = new Cliente(10, "Manuel", "Tuqueres");
        cliente.setCorreo("manu.tqrs@example.com");
        cliente.setTelefono("0999999999");
        cliente.setFechaRegistro(new Fecha(15, 5, 2023)); // 15/05/2023
    }
    /**
     * Se verifica que el identificador del cliente se recupere correctamente.
     */
    @Test
    void getClienteId() {
        assertEquals(10, cliente.getClienteId());
        System.out.println("ClienteId: " + cliente.getClienteId());
    }
    /**
     * Se verifica que el ID se establezca correctamente y que no acepte valores negativos.
     */
    @Test
    void setClienteId() {
        cliente.setClienteId(20);
        assertEquals(20, cliente.getClienteId());
        cliente.setClienteId(-5);  // No debería cambiar
        assertEquals(20, cliente.getClienteId());
        System.out.println("ClienteId después set: " + cliente.getClienteId());
    }
    /**
     * Se verifica la recuperación del nombre del cliente.
     */
    @Test
    void getNombre() {
        assertEquals("Manuel", cliente.getNombre());
        System.out.println("Nombre: " + cliente.getNombre());
    }
    /**
     * Se verifica la modificación del nombre del cliente.
     */
    @Test
    void setNombre() {
        cliente.setNombre("Carlos");
        assertEquals("Carlos", cliente.getNombre());
        System.out.println("Nombre después set: " + cliente.getNombre());
    }
    /**
     * Se verifica la recuperación del apellido del cliente.
     */

    @Test
    void getApellido() {
        assertEquals("Tuqueres", cliente.getApellido());
        System.out.println("Apellido: " + cliente.getApellido());
    }
    /**
     * Se verifica la modificación del apellido del cliente.
     */
    @Test
    void setApellido() {
        cliente.setApellido("Curay");
        assertEquals("Curay", cliente.getApellido());
        System.out.println("Apellido después set: " + cliente.getApellido());
    }
    /**
     * Se verifica la recuperación del correo del cliente.
     */

    @Test
    void getCorreo() {
        assertEquals("manu.tqrs@example.com", cliente.getCorreo());
        System.out.println("Correo: " + cliente.getCorreo());
    }
    /**
     * Se verifica la modificación del correo del cliente.
     */

    @Test
    void setCorreo() {
        cliente.setCorreo("carlos.curay@example.com");
        assertEquals("carlos.curay@example.com", cliente.getCorreo());
        System.out.println("Correo después set: " + cliente.getCorreo());
    }
    /**
     * Se verifica la recuperación del teléfono del cliente.
     */
    @Test
    void getTelefono() {
        assertEquals("0999999999", cliente.getTelefono());
        System.out.println("Teléfono: " + cliente.getTelefono());
    }
    /**
     * Se verifica la modificación del teléfono del cliente.
     */
    @Test
    void setTelefono() {
        cliente.setTelefono("0985493755");
        assertEquals("0985493755", cliente.getTelefono());
        System.out.println("Teléfono después set: " + cliente.getTelefono());
    }
    /**
     * Se verifica la recuperación de la fecha de registro del cliente.
     */
    @Test
    void getFechaRegistro() {
        assertEquals("15/05/2023", cliente.getFechaRegistro().obtenerFormatoCorto());
        System.out.println("Fecha Registro: " + cliente.getFechaRegistro().obtenerFormatoCorto());
    }
    /**
     * Se verifica la modificación de la fecha de registro del cliente.
     */
    @Test
    void setFechaRegistro() {
        Fecha nuevaFecha = new Fecha(1, 1, 2025);
        cliente.setFechaRegistro(nuevaFecha);
        assertEquals("01/01/2025", cliente.getFechaRegistro().obtenerFormatoCorto());
        System.out.println("Fecha Registro después set: " + cliente.getFechaRegistro().obtenerFormatoCorto());
    }
    /**
     * Se verifica que la representación en cadena del cliente contenga los datos esperados.
     */
    @Test
    void testToString() {
        String resultado = cliente.toString();
        assertTrue(resultado.contains("Manuel") && resultado.contains("Tuqueres"));
        System.out.println("toString:\n" + resultado);
    }
}
