package ec.edu.uce.dominio;
/**
 * Clase de prueba para la funcionalidad de la clase {@link Banco}.
 * Se verifica la correcta gestión de clientes, incluyendo creación, edición y eliminación.
 */

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class BancoTest {
    Banco banco;
    /**
     * Método de configuración antes de cada prueba.
     * Se inicializa un banco con algunos clientes de prueba.
     */
    @BeforeEach
    void setUp() {
        banco = new Banco();
        banco.agregarCliente(1, "Rommel", "Tuqueres");
        banco.agregarCliente(2, "Mercedes", "Diaz");
        banco.agregarCliente(3, "Carlos", "Diaz");
    }
    /**
     * Se verifica que un cliente pueda ser agregado correctamente.
     */
    @Test
    void agregarCliente() {
        banco.agregarCliente(4, "Samanta", "Tuqueres");
        assertNotNull(banco.getCliente(3));
        System.out.println("Agregar Cliente:\n" + banco.getCliente(3));
    }
    /**
     * Se verifica que los datos de un cliente puedan ser modificados correctamente.
     */

    @Test
    void editarCliente() {
        banco.editarCliente(1, 20, "Mariana", "Diaz");
        Cliente clienteEditado = banco.getCliente(1);
        assertEquals(20, clienteEditado.getClienteId());
        assertEquals("Mariana", clienteEditado.getNombre());
        System.out.println("Editar Cliente:\n" + clienteEditado);
    }
    /**
     * Se verifica que un cliente pueda ser eliminado correctamente.
     */
    @Test
    void eliminarCliente() {
        Cliente clienteEliminado = banco.getCliente(0);
        banco.eliminarCliente(0);
        assertNotEquals(clienteEliminado.getClienteId(), banco.getCliente(0).getClienteId());

        System.out.println("Eliminar Cliente en índice 0. Cliente eliminado: " + clienteEliminado);
    }
    /**
     * Se verifica que la consulta de clientes retorne información válida.
     */
    @Test
    void consultarClientes() {
        String listado = banco.consultarClientes();
        assertNotNull(listado);
        System.out.println("Listado de Clientes:\n" + listado);
    }
    /**
     * Se verifica que la representación en cadena del banco contenga la información esperada.
     */
    @Test
    void testToString() {
        System.out.println("Banco toString:\n" + banco.toString());
        assertTrue(banco.toString().contains("Clientes"));
    }
}
