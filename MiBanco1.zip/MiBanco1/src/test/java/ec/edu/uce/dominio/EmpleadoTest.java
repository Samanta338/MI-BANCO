package ec.edu.uce.dominio;
/**
 * Clase de prueba para la funcionalidad de la clase {@link Empleado}.
 * Se validan los métodos de acceso y modificación de atributos.
 */
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class EmpleadoTest {
    Empleado empleado;
    @BeforeEach
    void setUp() {
        Fecha fechaIngreso = new Fecha(15, 5, 2025);
        empleado = new Empleado(100, "Mercedes", "Diaz", Empleado.SALARIO_BASICO, "Gerente", fechaIngreso);
    }
    /**
     * Se verifica la recuperación del identificador del empleado.
     */
    @Test
    void getId() {
        assertEquals(100, empleado.getId());
        System.out.println("Id: " + empleado.getId());
    }
    /**
     * Se verifica la modificación del identificador del empleado.
     */
    @Test
    void setId() {
        empleado.setId(200);
        assertEquals(200, empleado.getId());
        System.out.println("Id después de set: " + empleado.getId());
    }
    /**
     * Se verifica la recuperación del nombre del empleado.
     */
    @Test
    void getNombre() {
        assertEquals("Mercedes", empleado.getNombre());
        System.out.println("Nombre: " + empleado.getNombre());
    }
    /**.
     * Se verifica la modificación del nombre del empleado.
     */
    @Test
    void setNombre() {
        empleado.setNombre("Rommel");
        assertEquals("Rommel", empleado.getNombre());
        System.out.println("Nombre después de set: " + empleado.getNombre());
    }
    /**
     * Se verifica la recuperación del apellido del empleado.
     */
    @Test
    void getApellido() {
        assertEquals("Diaz", empleado.getApellido());
        System.out.println("Apellido: " + empleado.getApellido());
    }
    /**
     * Se verifica la modificación del apellido del empleado.
     */
    @Test
    void setApellido() {
        empleado.setApellido("Diaz");
        assertEquals("Diaz", empleado.getApellido());
        System.out.println("Apellido después de set: " + empleado.getApellido());
    }
    /**
     * Se verifica la recuperación del salario del empleado.
     */
    @Test
    void getSalario() {
        assertEquals(Empleado.SALARIO_BASICO, empleado.getSalario());
        System.out.println("Salario: " + empleado.getSalario());
    }
    /**
     * Prueba del método {@link Empleado#setSalario(double)}.
     * Se verifica la modificación del salario del empleado.
     */

    @Test
    void setSalario() {
        empleado.setSalario(550.50);
        assertEquals(550.50, empleado.getSalario());
        System.out.println("Salario después de set: " + empleado.getSalario());
    }
    /**
     * Se verifica la recuperación del puesto del empleado.
     */
    @Test
    void getPuesto() {
        assertEquals("Gerente", empleado.getPuesto());
        System.out.println("Puesto: " + empleado.getPuesto());
    }
    /**
     * Se verifica la modificación del puesto del empleado.
     */
    @Test
    void setPuesto() {
        empleado.setPuesto("Director");
        assertEquals("Director", empleado.getPuesto());
        System.out.println("Puesto después de set: " + empleado.getPuesto());
    }
    /**
     * Se verifica la recuperación de la fecha de ingreso del empleado.
     */
    @Test
    void getFechaIngreso() {
        System.out.println("Fecha Ingreso: " + empleado.getFechaIngreso());
    }
    /**
     * Se verifica la modificación de la fecha de ingreso del empleado.
     */
    @Test
    void setFechaIngreso() {
        Fecha fecha = new Fecha(1, 1, 2025);
        empleado.setFechaIngreso(fecha);
        assertEquals(fecha, empleado.getFechaIngreso());
        System.out.println("Fecha Ingreso después de set: " + empleado.getFechaIngreso());
    }
    /**
     * Se verifica que la representación en cadena del empleado contenga los datos esperados.
     */
    @Test
    void testToString() {
        String texto = empleado.toString();
        assertTrue(texto.contains("Mercedes"));
        assertTrue(texto.contains("Diaz"));
        assertTrue(texto.contains("Gerente"));
        System.out.println("toString:\n" + texto);
    }
}
