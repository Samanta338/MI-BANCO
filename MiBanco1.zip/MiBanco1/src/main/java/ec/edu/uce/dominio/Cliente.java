package ec.edu.uce.dominio;
/**
 * Clase que representa a un cliente en el sistema bancario.
 * Contiene información personal y detalles de registro.
 *
 * @author Samanta Tuqueres
 */
public class Cliente {
        private int clienteId;
        private String nombre;
        private String apellido;
        private String correo;
        private String telefono;
        private Fecha fechaRegistro; // Composición
        /**
         * Constructor por defecto que inicializa los atributos con valores predeterminados.
         */
        public Cliente() {
            this.clienteId = 1;
            this.nombre = "Sin nombre";
            this.apellido = "Sin apellido";
            this.correo = "Sin correo";
            this.telefono = "Sin teléfono";
            this.fechaRegistro = new Fecha();
        }
        /**
         * Constructor con parámetros que permite definir los datos principales del cliente.
         *
         * @param id Identificador del cliente
         * @param nombre Nombre del cliente
         * @param apellido Apellido del cliente
         */
        public Cliente(int id, String nombre, String apellido) {
            this.clienteId = id;
            this.nombre = nombre;
            this.apellido = apellido;
            this.correo = "Sin correo";
            this.telefono = "Sin teléfono";
            this.fechaRegistro = new Fecha(); // Por defecto
        }
        /**
         * Constructor de copia que permite crear una instancia basada en otro cliente.
         *
         * @param nuevoCliente Cliente del cual se copiarán los datos
         */
        public Cliente(Cliente nuevoCliente) {
            this.clienteId = nuevoCliente.clienteId;
            this.nombre = nuevoCliente.nombre;
            this.apellido = nuevoCliente.apellido;
            this.correo = nuevoCliente.correo;
            this.telefono = nuevoCliente.telefono;
            this.fechaRegistro = new Fecha(nuevoCliente.fechaRegistro.getDia(),
                    nuevoCliente.fechaRegistro.getMes(),
                    nuevoCliente.fechaRegistro.getAnio());
        }

        // Getters y setters
        /**
         * Obtiene el identificador único del cliente.
         *
         * @return Identificador del cliente
         */
        public int getClienteId() { return clienteId; }
        /**
         * Establece el identificador único del cliente.
         *
         * @param clienteId Nuevo identificador del cliente
         */
        public void setClienteId(int clienteId) {
            if (clienteId >= 0) this.clienteId = clienteId;
            else System.out.println("ID inválido");
        }
        /**
         * Obtiene el nombre del cliente.
         *
         * @return Nombre del cliente
         */
        public String getNombre() { return nombre; }
        /**
         * Establece el nombre del cliente.
         *
         * @param nombre Nuevo nombre del cliente
         */
        public void setNombre(String nombre) { this.nombre = nombre; }
        /**
         * Obtiene el apellido del cliente.
         *
         * @return Apellido del cliente
         */
        public String getApellido() { return apellido; }
        /**
         * Establece el apellido del cliente.
         *
         * @param apellido Nuevo apellido del cliente
         */
         public void setApellido(String apellido) { this.apellido = apellido; }
        /**
         * Obtiene el correo electrónico del cliente.
         *
         * @return Correo electrónico del cliente
         */
        public String getCorreo() { return correo; }
        /**
         * Establece el correo electrónico del cliente.
         *
         * @param correo Nuevo correo del cliente
         */
        public void setCorreo(String correo) { this.correo = correo; }
        /**
         * Obtiene el número de teléfono del cliente.
         *
         * @return Número de teléfono del cliente
         */
        public String getTelefono() { return telefono; }
        /**
         * Establece el número de teléfono del cliente.
         *
         * @param telefono Nuevo número de teléfono del cliente
         */
        public void setTelefono(String telefono) { this.telefono = telefono; }
        /**
         * Obtiene la fecha de registro del cliente.
         *
         * @return Fecha de registro
         */
        public Fecha getFechaRegistro() { return fechaRegistro; }
        /**
         * Establece la fecha de registro del cliente.
         *
         * @param fecha Nueva fecha de registro
         */
        public void setFechaRegistro(Fecha fecha) { this.fechaRegistro = fecha; }

        /**
         * Representación en cadena del objeto Cliente.
         *
         * @return Información del cliente en formato de texto
         */
        public String toString() {
            return "Id: " + clienteId +
                    " Nombre: " + nombre +
                    " Apellido: " + apellido +
                    " Correo: " + correo +
                    " Fecha de Registro: " + fechaRegistro +
                    " Teléfono: " + telefono + "\n";
        }
    }
