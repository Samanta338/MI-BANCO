package ec.edu.uce.dominio;

/**
 * Clase de prueba para la funcionalidad de la clase Cliente.
 * Contiene métodos para verificar constructores, getters y setters.
 */

public class TestCliente {
    Cliente cliente;
    public void testConstructor(){
        cliente = new Cliente();
    }
    /**
     * Prueba del constructor parametrizado de la clase Cliente.
     *
     * @param id Identificador único del cliente
     * @param nombre Nombre del cliente
     * @param apellido Apellido del cliente
     */
    public void testConstructor(int id,String nombre, String apellido){
        cliente = new Cliente(id, nombre, apellido);
    }

    /**
     * Prueba del constructor de copia de la clase Cliente.
     *
     * @param c Cliente del cual se copiarán los datos
     */

    public void testConstructor2(Cliente c){
        cliente = new Cliente(c);
    }
    /**
     * Prueba de los métodos setters de la clase Cliente.
     * Se establecen valores personalizados para probar la asignación.
     */

    public void testSet(){
        cliente.setClienteId(2387);
        cliente.setNombre("Samanta");
        cliente.setApellido("Tuqueres");
        cliente.setCorreo("samantatuqueres2387@gmail.com");
        cliente.setTelefono("0989019761");
        cliente.setFechaRegistro(new Fecha(13, 5, 2025));

    }
    /**
     * Prueba de los métodos getters de la clase Cliente.
     * Se imprimen los valores obtenidos.
     */

    public void testGet(){
        System.out.println("Id:" + cliente.getClienteId());
        System.out.println("Nombre:" + cliente.getNombre());
        System.out.println("Apellido: " + cliente.getApellido());
        System.out.println("Correo: " + cliente.getCorreo());
        System.out.println("Teléfono: " + cliente.getTelefono());
        System.out.println("Fecha de Registro: " + cliente.getFechaRegistro());
    }
}
