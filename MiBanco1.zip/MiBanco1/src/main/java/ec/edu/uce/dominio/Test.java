package ec.edu.uce.dominio;
/**
 * Clase de prueba para la funcionalidad de la clase Cliente.
 * Permite probar constructores y métodos de acceso/modificación.
 */

public class Test {
    public static TestCliente testCliente;
    public static void main(String[] args){
        testCliente = new TestCliente();
        testCliente.testConstructor();
        testCliente.testGet();
        testCliente.testConstructor2(new Cliente(4, "Samanta", "Tuqueres"));
        testCliente.testSet();
    }
}
