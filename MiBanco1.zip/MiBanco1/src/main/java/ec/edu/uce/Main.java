package ec.edu.uce;
/**
 * Clase principal que ejecuta pruebas sobre la gestión de clientes en un banco.
 * Se agregan clientes, se modifican datos y se consultan registros.
 */
import ec.edu.uce.dominio.Banco;
import ec.edu.uce.dominio.Cliente;
public class Main {
    /**
     * Método principal que inicializa un banco y gestiona clientes.
     */
    public static void main(String[] arg){
        Banco banco = new Banco();
        System.out.println(banco);
        // Agregando clientes al banco
        banco.agregarCliente(2, "Juan", "Perez");
        banco.agregarCliente(3, "Maria", "Perez");
        banco.agregarCliente(4, "Samanta", "Tuqueres");
        banco.agregarCliente(5, "Noemi", "Alvear");
        banco.agregarCliente(6, "Juan", "Perez");
        banco.agregarCliente(7, "Maria", "Perez");
        banco.agregarCliente(8, "Samanta", "Tuqueres");
        banco.agregarCliente(9, "Noemi", "Alvear");
        // Consulta de un cliente específico
        System.out.println("Reporte del cliente en índice 1:\n" + banco.getCliente(1));
        // Edición de datos de un cliente
        banco.editarCliente(0, 200, "Marianela", "Diaz");
        // Consulta y listado de clientes registrados
        System.out.println("Listado de clientes:\n" + banco.consultarClientes());
        // Creación de un objeto Cliente y modificación de su ID
        Cliente cliente = new Cliente(5, "Samanta", "Tuqueres");
        cliente.setClienteId(-100);
        // Impresión de la información del cliente creado
        System.out.println("Cliente creado:\n" + cliente);
    }
}
