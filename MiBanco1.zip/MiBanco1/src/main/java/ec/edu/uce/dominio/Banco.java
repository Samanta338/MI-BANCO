package ec.edu.uce.dominio;
/**
 * Clase que representa un banco con clientes y empleados.
 * Permite la gestión de clientes y empleados asociados al banco.
 *
 * @author Samanta Tuqueres
 */

public class Banco {
    /**
     * ATRIBUTOS
     */
    private String nombre;
    private int id;
    private static Cliente[] clientes;      // Variable estática
    private static Empleado[] empleados;    // Variable estática
    private static int numClientes;         // Variable estática
    private static int numEmpleados;        // Variable estática
    // Bloque estático para inicializar los arreglos de clientes y empleados
    static {
        clientes = new Cliente[3];          // Inicializa clientes con un arreglo de tamaño 3
        empleados = new Empleado[3];        // Inicializa empleados con un arreglo de tamaño 3
        numClientes = 0;
        numEmpleados = 0;
    }
    /**
     * CONSTRUCTO VACIO  que inicializa el banco con valores predeterminados.
     */
    public Banco() {
        this("sin nombre", 1, new Cliente[3], new Empleado[3], 0, 0);
    }
    /**
     * Constructor parametrizado para inicializar el banco.
     *
     * @param nombre Nombre del banco
     * @param id Identificador del banco
     * @param clientes Arreglo de clientes
     * @param empleados Arreglo de empleados
     * @param numClientes Número de clientes
     * @param numEmpleados Número de empleados
     */
    public Banco(String nombre, int id, Cliente[] clientes, Empleado[] empleados, int numClientes, int numEmpleados) {
        this.nombre = nombre;
        this.id = id;
        this.clientes = clientes;
        this.empleados = empleados;
        this.numClientes = numClientes;
        this.numEmpleados = numEmpleados;
    }

    /**
     * METODOS GETTERS Y SETTERS
     */
    /**

     * Obtiene el nombre del banco.
     *
     * @return Nombre del banco
     */

    public String getNombre() {
        return nombre;
    }
    /**
     * Establece el nombre del banco.
     *
     * @param nombre Nuevo nombre del banco
     */

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    /**
     * Obtiene el ID del banco.
     *
     * @return ID del banco
     */
    public int getId() {
        return id;
    }
    /**
     * Establece el ID del banco.
     *
     * @param id Nuevo ID del banco
     */
    public void setId(int id) {
        this.id = id;
    }
    /**
     * Obtiene un cliente en un índice específico.
     *
     * @param indice Índice del cliente
     * @return Cliente encontrado, o null si el índice es inválido
     */
    public Cliente getCliente(int indice) {
        if (indice >= 0 && indice < numClientes) {
            return clientes[indice];
        }
        return null;
    }
    /**
     * Obtiene el número de empleados del banco.
     *
     * @return Número de empleados
     */
    public int getNumEmpleados() {
        return numEmpleados;
    }
    /**
     * Obtiene el arreglo de empleados.
     *
     * @return Arreglo de empleados
     */
    public Empleado[] getEmpleados() {
        return empleados;
    }
    /**
     * Establece el número de clientes del banco.
     *
     * @param numClientes Nuevo número de clientes
     */
    public void setNumClientes(int numClientes) {
        this.numClientes = numClientes;
    }

    /**
     * Establece el número de empleados del banco.
     *
     * @param numEmpleados Nuevo número de empleados
     */
    public void setNumEmpleados(int numEmpleados) {
        this.numEmpleados = numEmpleados;
    }

    /**
     * Relación entre Banco y Cliente/Empleado
     */
    public void setClientes(Cliente[] clientes) {
        if (clientes == null || clientes.length == 0) {
            System.out.println("Error: El arreglo de clientes no puede estar vacío.");
        } else {
            this.clientes = clientes;
        }
    }

    public void setEmpleados(Empleado[] empleados) {
        if (empleados == null || empleados.length == 0) {
            System.out.println("Error: El arreglo de empleados no puede estar vacío.");
        } else {
            this.empleados = empleados;
        }
    }

    /**
     * METODO TO STRING
     */

    /**
     * Representación en cadena del objeto Banco.
     *
     * @return String con los detalles del banco
     */
    @Override
    public String toString() {
        return "Banco{id=" + id +
                ", nombre='" + nombre + '\'' +
                ", numeroDeClientes=" + numClientes +
                ", numeroDeEmpleados=" + numEmpleados + '}';
    }
    /**
     * CRUD: Crear cliente
     */
    /**

     * Agrega un nuevo cliente al banco.
     *
     * @param id ID del cliente
     * @param nombre Nombre del cliente
     * @param apellido Apellido del cliente
     */
    public void agregarCliente(int id, String nombre, String apellido) {
        Cliente cliente = new Cliente(id, nombre, apellido);
        if (numClientes == clientes.length) {
            Cliente[] cliaux = clientes;
            clientes = new Cliente[numClientes + 1];
            System.arraycopy(cliaux, 0, clientes, 0, numClientes);
        }
        clientes[numClientes] = cliente;
        numClientes++;
    }
    /**
     * CRUD: editar cliente
     */

    /**
     * Editar los datos de un cliente existente.
     * @param indice Índice del cliente a modificar
     * @param id Nuevo ID del cliente
     * @param nombre Nuevo nombre del cliente
     * @param apellido Nuevo apellido del cliente
     */

    public void editarCliente(int indice, int id, String nombre, String apellido) {
        if (indice >= 0 && indice < numClientes) {
            Cliente cliente = clientes[indice];
            cliente.setClienteId(id);
            cliente.setNombre(nombre);
            cliente.setApellido(apellido);
        }
    }
    /**
     * CRUD: eliminar cliente
     */

    /**
     * Elimina un cliente del banco.
     *
     * @param indice Índice del cliente a eliminar
     */
    public void eliminarCliente(int indice) {
        if (indice >= 0 && indice < numClientes) {
            // Mover todos los clientes una posición a la izquierda a partir del índice
            for (int i = indice; i < numClientes - 1; i++) {
                clientes[i] = clientes[i + 1];
            }
            clientes[numClientes - 1] = null;
            numClientes--;
        }
    }

    /**
     * CRUD: consultar clientes
     */

    /**
     * Consulta los clientes actuales del banco.
     *
     * @return Información de los clientes en formato de texto
     */

    public String consultarClientes() {
        StringBuilder texto = new StringBuilder();
        for (Cliente cliente : clientes) {
            if (cliente != null) {
                texto.append(cliente.toString()).append("\n");
            }
        }
        return texto.toString();
    }
}







