package ec.edu.uce.dominio;
/**
 * Clase que representa a un empleado en el sistema.
 * Contiene información personal, salario y fecha de ingreso.
 *
 * @author Samanta Tuqueres
 */
public class Empleado {
    public static int contador;
    public static final double SALARIO_BASICO = 470.00;
    protected final int codigo;
    protected int id;
    protected String nombre;
    protected String apellido;
    protected double salario;
    protected String puesto;
    // Agregación: Fecha es un objeto separado que se asigna al empleado
    protected Fecha fechaIngreso;

    static {
        contador = 0;
    }
    /**
     * Constructor por defecto que inicializa los atributos con valores predeterminados.
     */

    public Empleado() {
        this(0, "SinNombre", "SinApellido", SALARIO_BASICO, "SinPuesto", new Fecha());
    }
    /**
     * Constructor parametrizado que permite establecer los valores del empleado.
     *
     * @param id Identificador único del empleado
     * @param nombre Nombre del empleado
     * @param apellido Apellido del empleado
     * @param salario Salario del empleado
     * @param puesto Puesto de trabajo del empleado
     * @param fechaIngreso Fecha de ingreso del empleado
     */
    public Empleado(int id, String nombre, String apellido, double salario, String puesto, Fecha fechaIngreso) {
        contador++;
        this.codigo = contador;
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.salario = salario;
        this.puesto = puesto;
        this.fechaIngreso = fechaIngreso;
    }

    /**
     * Métodos Getters y Setters
     */
    /**
     * Obtiene el ID del empleado.
     *
     * @return ID del empleado
     */
    public int getId() {
        return id;
    }
    /**
     * Establece el ID del empleado.
     *
     * @param id Nuevo ID del empleado
     */
    public void setId(int id) {
        this.id = id;
    }
    /**
     * Obtiene el nombre del empleado.
     *
     * @return Nombre del empleado
     */

    public String getNombre() {
        return nombre;
    }
    /**
     * Establece el nombre del empleado.
     *
     * @param nombre Nuevo nombre del empleado
     */

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    /**
     * Obtiene el apellido del empleado.
     *
     * @return Apellido del empleado
     */
    public String getApellido() {
        return apellido;
    }
    /**
     * Establece el apellido del empleado.
     *
     * @param apellido Nuevo apellido del empleado
     */

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
    /**
     * Obtiene el salario del empleado.
     *
     * @return Salario del empleado
     */
    public double getSalario() {
        return salario;
    }
    /**
     * Establece el salario del empleado.
     *
     * @param salario Nuevo salario del empleado
     */
    public void setSalario(double salario) {
        this.salario = salario;
    }
    /**
     * Obtiene el puesto de trabajo del empleado.
     *
     * @return Puesto del empleado
     */

    public String getPuesto() {
        return puesto;
    }
    /**
     * Establece el puesto de trabajo del empleado.
     *
     * @param puesto Nuevo puesto del empleado
     */

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }
    /**
     * Obtiene la fecha de ingreso del empleado.
     *
     * @return Fecha de ingreso del empleado
     */

    public Fecha getFechaIngreso() {
        return fechaIngreso;
    }
    /**
     * Establece la fecha de ingreso del empleado.
     *
     * @param fechaIngreso Nueva fecha de ingreso del empleado
     */

    public void setFechaIngreso(Fecha fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    /**
     * Representación en cadena del objeto Empleado.
     *
     * @return Información del empleado en formato de texto
     */

    @Override
    public String toString() {
        return  "Empleado:\n" +
                " Codigo=" + codigo +
                " Id=" + id +
                " Nombre='" + nombre + '\'' +
                " Apellido='" + apellido + '\'' +
                " Salario=" + salario +
                " Puesto='" + puesto + '\'' +
                " FechaIngreso=" + (fechaIngreso != null ? fechaIngreso.obtenerFormatoCorto() : "N/A");
    }
}


